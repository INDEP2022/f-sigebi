export const GoodsData = [
  {
    goodId: '64554',
    description: 'Planta para Soldar',
    amout: '1',
    identifier: 'TRANS',
  },
  {
    goodId: '3121423',
    description: 'Planta para Soldar 2',
    amout: '1',
    identifier: 'TRANS',
  },
];

export const DocsData = [
  {
    key: 'OFERCOMER1',
    document: 'Punlicación de Convocatoria',
  },
  {
    key: 'OFERCOMER2',
    document:
      'Bases No 126 rubricadas y firmadas por el adquirente, incluye anexo 1',
  },
];
