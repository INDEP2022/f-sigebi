import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-choose-document',
  templateUrl: './choose-document.component.html',
  styles: [],
})
export class ChooseDocumentComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
