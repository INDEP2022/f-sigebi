export const DocsData = [
  {
    key: 'OFERCOMER1',
    document: 'Punlicación de Convocatoria',
  },
  {
    key: 'OFERCOMER2',
    document:
      'Bases No 126 rubricadas y firmadas por el adquirente, incluye anexo 1',
  },
  {
    key: 'OFERCOMER3',
    document: 'Acta de apertura de propuesta económicas y fallo',
  },
];
