export const COLUMNS = {
  key: {
    title: 'Clave',
    sort: false,
  },
  document: {
    title: 'Documento',
    sort: false,
  },
};
